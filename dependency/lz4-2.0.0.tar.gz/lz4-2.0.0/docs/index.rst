
LZ4 compression library bindings for Python
===========================================

Contents
--------
.. toctree::
   :maxdepth: 2

   intro
   install
   quickstart
   userguide
   contributors
   license

Indices
-------
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
